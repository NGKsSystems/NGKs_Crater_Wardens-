# Phase 9 Proof — NGKs Crater Wardens V1
Generated: 2026-03-24 08:48:25

## Files Created

### scenes/level/test_lane_2.tscn
- Size:        9430 bytes
- Lines:       236
- Nodes:       48
- Connections: 17

Ground segments:
  GroundL2Left   pos=(750, 570)   shape=2300x40   [x=-400 to x=1900]
  GroundL2Mid    pos=(3050, 570)  shape=1500x40   [x=2300 to x=3800]
  GroundL2Right  pos=(5200, 570)  shape=2000x40   [x=4200 to x=6200]

Hazard gaps:
  HazardGap1     pos=(2100, 620)  [gap x=1900→2300, 400px]
  HazardGap2     pos=(4000, 620)  [gap x=3800→4200, 400px]

Mines:
  Mine1  pos=(600,  536)
  Mine2  pos=(1450, 536)
  Mine3  pos=(2600, 536)
  Mine4  pos=(3000, 536)

Platforms (128x20 narrow):
  PlatL2A  pos=(1200, 490)  [jump-chain start]
  PlatL2B  pos=(1420, 490)  [jump-chain end, 220px CC]
  PlatL2C  pos=(3300, 490)  [S5 platform]

Enemies:
  HoverA   pos=(900,  520)
  HoverB   pos=(1650, 520)
  HoverC   pos=(3500, 520)
  DroneA   pos=(2350, 380)
  DroneB   pos=(3600, 380)
  TurretA  pos=(2800, 524)
  TurretB  pos=(4300, 524)

Checkpoints:
  CP1  pos=(1500, 484)  index=1
  CP2  pos=(3000, 484)  index=2
  CP3  pos=(4300, 484)  index=3

FinishTrigger  pos=(4700, 484)
Rover spawn    pos=(80,   534)

---

### scenes/level/test_lane_3.tscn
- Size:        10391 bytes
- Lines:       260
- Nodes:       55
- Connections: 18

Ground segments:
  GroundL3Left   pos=(1000, 570)  shape=2800x40   [x=-400 to x=2400]
  GroundL3Mid    pos=(3400, 570)  shape=1200x40   [x=2800 to x=4000]
  GroundL3Right  pos=(5200, 570)  shape=1600x40   [x=4400 to x=6000]

Hazard gaps:
  HazardGap1     pos=(2600, 620)  [gap x=2400→2800, 400px]
  HazardGap2     pos=(4200, 620)  [gap x=4000→4400, 400px]

Mines:
  Mine1  pos=(3150, 536)
  Mine2  pos=(4600, 536)

Platforms (128x20 narrow — jump chain + S5):
  PlatL3A  pos=(1200, 490)  [chain step 1]
  PlatL3B  pos=(1400, 480)  [chain step 2, 200px CC from A]
  PlatL3C  pos=(1750, 470)  [chain step 3, 350px CC from B]
  PlatL3D  pos=(2100, 490)  [chain step 4, 350px CC from C]
  PlatL3E  pos=(3600, 490)  [S5 platform]

Enemies:
  HoverA   pos=(600,  520)
  HoverB   pos=(900,  520)
  HoverC   pos=(3300, 520)
  HoverD   pos=(3800, 520)
  DroneA   pos=(1000, 380)
  DroneB   pos=(2600, 360)
  DroneC   pos=(3650, 360)
  DroneD   pos=(4550, 360)
  TurretA  pos=(3000, 524)
  TurretB  pos=(4450, 524)

Checkpoints:
  CP1  pos=(1400, 484)  index=1
  CP2  pos=(3200, 484)  index=2
  CP3  pos=(4400, 484)  index=3

FinishTrigger  pos=(5000, 484)
Rover spawn    pos=(80,   534)

---

## Scope Compliance
- No scripts modified
- No mechanics added
- All scenes reuse: rover.tscn, test_lane.gd, crater_gap.tscn, mine.tscn,
  drone_flyer.tscn, hover_attacker.tscn, ground_turret.tscn,
  checkpoint_marker.tscn, stage_controller.gd, hud.tscn
- Coordinates taken verbatim from docs/level_placement_specs.md
