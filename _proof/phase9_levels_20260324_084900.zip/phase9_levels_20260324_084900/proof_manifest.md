# Phase 9 Proof — NGKs Crater Wardens V1
Generated: 2026-03-24 08:49:00

## Files Created

### scenes/level/test_lane_2.tscn
- Size:        9430 bytes
- load_steps:  15  (10 ext_resources + 5 sub_resources)
- uid:         uid://testlane2
- Script:      res://scripts/level/test_lane.gd  (unmodified)

Ground segments:
  GroundL2Left   pos=(750,  570)  shape=2300x40  [x=-400 → x=1900]
  GroundL2Mid    pos=(3050, 570)  shape=1500x40  [x=2300 → x=3800]
  GroundL2Right  pos=(5200, 570)  shape=2000x40  [x=4200 → x=6200]

Hazard gaps:
  HazardGap1  pos=(2100, 620)  [gap x=1900→2300, 400 px]
  HazardGap2  pos=(4000, 620)  [gap x=3800→4200, 400 px]

Mines:
  Mine1  pos=(600,  536)   Section 1
  Mine2  pos=(1450, 536)   Section 2
  Mine3  pos=(2600, 536)   Section 4
  Mine4  pos=(3000, 536)   Section 4

Platforms (128x20 narrow):
  PlatL2A  pos=(1200, 490)  jump-chain start
  PlatL2B  pos=(1420, 490)  jump-chain end (220 px CC from A)
  PlatL2C  pos=(3300, 490)  Section 5 platform

Enemies:
  HoverA   pos=(900,  520)   Section 1
  HoverB   pos=(1650, 520)   Section 2
  HoverC   pos=(3500, 520)   Section 5
  DroneA   pos=(2350, 380)   Section 3
  DroneB   pos=(3600, 380)   Section 5
  TurretA  pos=(2800, 524)   Section 4
  TurretB  pos=(4300, 524)   Section 6

Checkpoints:
  CP1  pos=(1500, 484)  index=1
  CP2  pos=(3000, 484)  index=2
  CP3  pos=(4300, 484)  index=3

FinishTrigger  pos=(4700, 484)
Rover spawn    pos=(80,   534)
Connections:   17  (13 player_killed + 3 checkpoint_reached + 1 body_entered)

---

### scenes/level/test_lane_3.tscn
- Size:        10391 bytes
- load_steps:  15  (10 ext_resources + 5 sub_resources)
- uid:         uid://testlane3
- Script:      res://scripts/level/test_lane.gd  (unmodified)

Ground segments:
  GroundL3Left   pos=(1000, 570)  shape=2800x40  [x=-400 → x=2400]
  GroundL3Mid    pos=(3400, 570)  shape=1200x40  [x=2800 → x=4000]
  GroundL3Right  pos=(5200, 570)  shape=1600x40  [x=4400 → x=6000]

Hazard gaps:
  HazardGap1  pos=(2600, 620)  [gap x=2400→2800, 400 px]
  HazardGap2  pos=(4200, 620)  [gap x=4000→4400, 400 px]

Mines:
  Mine1  pos=(3150, 536)   Section 4
  Mine2  pos=(4600, 536)   Section 6

Platforms (128x20 narrow — jump chain + S5):
  PlatL3A  pos=(1200, 490)  chain step 1
  PlatL3B  pos=(1400, 480)  chain step 2  (200 px CC from A)
  PlatL3C  pos=(1750, 470)  chain step 3  (350 px CC from B)
  PlatL3D  pos=(2100, 490)  chain step 4  (350 px CC from C)
  PlatL3E  pos=(3600, 490)  Section 5 platform

Enemies:
  HoverA   pos=(600,  520)   Section 1
  HoverB   pos=(900,  520)   Section 1
  HoverC   pos=(3300, 520)   Section 4
  HoverD   pos=(3800, 520)   Section 5
  DroneA   pos=(1000, 380)   Section 1
  DroneB   pos=(2600, 360)   Section 3
  DroneC   pos=(3650, 360)   Section 5
  DroneD   pos=(4550, 360)   Section 6
  TurretA  pos=(3000, 524)   Section 4
  TurretB  pos=(4450, 524)   Section 6

Checkpoints:
  CP1  pos=(1400, 484)  index=1
  CP2  pos=(3200, 484)  index=2
  CP3  pos=(4400, 484)  index=3

FinishTrigger  pos=(5000, 484)
Rover spawn    pos=(80,   534)
Connections:   19  (14 player_killed + 3 checkpoint_reached + 1 body_entered)

---

## Scope Compliance
- Zero scripts modified
- Zero new mechanics
- All enemy/hazard/checkpoint scenes reused unchanged:
    rover.tscn, test_lane.gd, crater_gap.tscn, mine.tscn,
    drone_flyer.tscn, hover_attacker.tscn, ground_turret.tscn,
    checkpoint_marker.tscn, stage_controller.gd, hud.tscn
- Coordinates taken verbatim from docs/level_placement_specs.md

## Spec Cross-check — Level 2

| Spec Item                   | Placed At         | Status |
|-----------------------------|-------------------|--------|
| S1 Mine x=600               | Mine1 (600, 536)  | OK     |
| S1 Hover x=900              | HoverA (900, 520) | OK     |
| S2 Platform start x=1200    | PlatL2A (1200,490)| OK     |
| S2 Platform end x=1420      | PlatL2B (1420,490)| OK     |
| S2 Mine x=1450              | Mine2 (1450, 536) | OK     |
| S2 Hover x=1650             | HoverB (1650, 520)| OK     |
| S3 Gap x=1900→2300          | G2L ends at 1900  | OK     |
| S3 Drone (2350, 380)        | DroneA (2350, 380)| OK     |
| S4 Mine x=2600              | Mine3 (2600, 536) | OK     |
| S4 Turret x=2800            | TurretA (2800,524)| OK     |
| S4 Mine x=3000              | Mine4 (3000, 536) | OK     |
| S5 Platform x=3300          | PlatL2C (3300,490)| OK     |
| S5 Hover x=3500             | HoverC (3500, 520)| OK     |
| S5 Drone (3600, 380)        | DroneB (3600, 380)| OK     |
| S6 Gap x=3800→4200          | G2M ends at 3800  | OK     |
| S6 Turret x=4300            | TurretB (4300,524)| OK     |
| CP1 x=1500                  | CP1 (1500, 484)   | OK     |
| CP2 x=3000                  | CP2 (3000, 484)   | OK     |
| CP3 x=4300                  | CP3 (4300, 484)   | OK     |

## Spec Cross-check — Level 3

| Spec Item                   | Placed At          | Status |
|-----------------------------|--------------------|--------|
| S1 Hover x=600              | HoverA (600, 520)  | OK     |
| S1 Hover x=900              | HoverB (900, 520)  | OK     |
| S1 Drone (1000, 380)        | DroneA (1000, 380) | OK     |
| S2 PlatA x=1200             | PlatL3A (1200, 490)| OK     |
| S2 PlatB x=1400 (200px CC)  | PlatL3B (1400, 480)| OK     |
| S2 PlatC x=1750 (350px CC)  | PlatL3C (1750, 470)| OK     |
| S2 PlatD x=2100 (350px CC)  | PlatL3D (2100, 490)| OK     |
| S3 Gap x=2400→2800          | G3L ends at 2400   | OK     |
| S3 Drone (2600, 360)        | DroneB (2600, 360) | OK     |
| S4 Turret x=3000            | TurretA (3000, 524)| OK     |
| S4 Mine x=3150              | Mine1 (3150, 536)  | OK     |
| S4 Hover x=3300             | HoverC (3300, 520) | OK     |
| S5 Platform x=3600          | PlatL3E (3600, 490)| OK     |
| S5 Drone (3650, 360)        | DroneC (3650, 360) | OK     |
| S5 Hover x=3800             | HoverD (3800, 520) | OK     |
| S6 Gap x=4000→4400          | G3M ends at 4000   | OK     |
| S6 Turret x=4450            | TurretB (4450, 524)| OK     |
| S6 Mine x=4600              | Mine2 (4600, 536)  | OK     |
| S6 Drone (4550, 360)        | DroneD (4550, 360) | OK     |
| S7 Finish x=5000            | FinishTrigger 5000 | OK     |
| CP1 x=1400                  | CP1 (1400, 484)    | OK     |
| CP2 x=3200                  | CP2 (3200, 484)    | OK     |
| CP3 x=4400                  | CP3 (4400, 484)    | OK     |
